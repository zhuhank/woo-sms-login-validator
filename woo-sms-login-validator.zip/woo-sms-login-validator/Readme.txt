=== Woo SMS  Login Validator===
Contributors: shudong zhu
Donate link: 
Tags: sms,phone,woocomerence,login,wordpress,短信,登陆
Requires at least: 4.0
Tested up to: 4.0
Stable tag: 0.5
License: GPLv2 or later

 This plugin can let buyer login and register with their real phone num. 
(此插件利用短信验证,使买家用真实的手机号进行注册登陆购物。)
 
== Description ==

 This plugin can let buyer login and register with their real phone num. 
(此插件利用短信验证,使买家用真实的手机号进行注册登陆购物。)


= 插件介绍 =
此插件集成了阿里短信服务,使买家需以真实的手机号来注册登陆
以手机号注册登陆也更符合国内的使用习惯

联系方式:
邮箱:nkg_hank@126.com
微信号:china_njit_dota_hope

**目前插件的功能：**

1. 此插件集成了阿里短信服务,使买家需以真实的手机号来注册登陆

仅售：￥150 RMB 


**Current Features:**

1. This plugin can let buyer login and register with their real phone num. 


only：￥150 RMB 

== Screenshots ==

1. myaccount login
2. checkout login
3. 插件后台 - General Settings


== Changelog ==
Initial version